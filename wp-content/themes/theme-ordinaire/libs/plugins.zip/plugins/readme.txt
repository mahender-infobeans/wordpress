=== TGM Example Plugin ===
Contributors: griffinjt, jrf
Tags: php version, mysql version
Requires at least: 2.5.0
Tested up to: 4.5
Stable tag: 1.0.1
License: GPLv3

Example plugin to demonstrate the ability to handle bundled plugins with the TGM Plugin Activation library.

== Description ==

Example plugin to demonstrate the ability to handle bundled plugins with the TGM Plugin Activation library.

Please visit the [TGM Plugin Activation](http://tgmpluginactivation.com/) website for more information.


== Changelog ==

= 1.0.1 =
* Minor tidying up.

= 1.0 =
* Initial release.


== Installation ==

1. Extract the .zip file for this plugin and upload its contents to the `/wp-content/plugins/` directory.
1. Activate the plugin through the "Plugins" menu in WordPress.

